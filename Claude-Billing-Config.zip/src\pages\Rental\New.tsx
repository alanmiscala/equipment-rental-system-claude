import {
  useNavigate,
  useSearchParams,
} from "react-router-dom";

import RentalForm from "@/features/rental/components/RentalForm";

import type {
  RentalFormData,
} from "@/features/rental/components/RentalForm";

import { useRental } from "@/features/rental/context/RentalContext";
import { useAssignment } from "@/features/assignment/context/AssignmentContext";
import { useToast } from "@/components/ui/toast/ToastContext";
import { useProject } from "@/features/project/context/ProjectContext";

import { generateRentalNumber } from "@/features/rental/utils/generateRentalNumber";
import {
  getAssignmentProjectError,
  getRentalAssignmentPrefill,
} from "@/features/rental/utils/rentalFormOptions";
import { resolveAssignmentRentalLookup } from "@/features/rental/utils/assignmentRentalLookup";

export default function NewRental() {
  const navigate =
    useNavigate();

  const [searchParams] =
    useSearchParams();

  const assignmentQuery = searchParams.get("assignment");

  const equipmentParam =
    searchParams.get(
      "equipment"
    );

  const {
    assignments,
  } = useAssignment();

  const assignmentLookup = resolveAssignmentRentalLookup(assignmentQuery, assignments);
  const assignment = assignmentLookup.state === "found" ? assignmentLookup.assignment : undefined;

  const initialEquipmentId =
    assignment?.equipmentId ??
    equipmentParam ??
    "";

  const assignmentPrefill = getRentalAssignmentPrefill(assignment);

  const {
    addRental,
    rentals,
  } = useRental();

  const { projects } = useProject();
  const assignmentProjectError = getAssignmentProjectError(assignment, projects);

    const {
    showToast,
  } = useToast();

  function handleSubmit(
    data: RentalFormData
  ) {
    const rentalId =
      crypto.randomUUID();

      
      const rental = {
        id: rentalId,

        rentalNumber: generateRentalNumber(rentals),
      
        equipmentId:
          data.equipmentId,

        customerId: data.customerId,

        projectId: data.projectId,

        operatorId: data.operatorId,

        assignmentId: assignmentPrefill.assignmentId,
      
        customer:
          data.customer,
      
        project:
          projects.find((project) => project.id === data.projectId)?.projectName ?? "",
      
        rentedBy:
          "",
      
        dateOut: data.dateOut,
      
        expectedReturn:
          data.expectedReturn,

        rentalType: data.rentalType || undefined,

        billingMethod: data.billingMethod || undefined,
      
      };

    const result = addRental(rental);

    if (!result.success) {
      showToast(
        result.message ??
          "Unable to create rental.",
        "error"
      );

      return;
    }

    showToast(
      "Rental created successfully",
      "success"
    );

    navigate(
      `/rentals/${rentalId}/workspace`
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6 p-6">

      <div>

        <h1 className="text-3xl font-bold">
          New Rental
        </h1>

        <p className="mt-2 text-gray-500">

          {assignment
            ? "Rental is being created from an existing assignment."
            : "Create a rental transaction."}

        </p>

      </div>

      {assignmentLookup.state === "loading" ? <p className="text-slate-500">Loading assignment…</p> : "message" in assignmentLookup ? <p className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">{assignmentLookup.message}</p> : <RentalForm
        onSubmit={
          handleSubmit
        }
        initialEquipmentId={
          initialEquipmentId ||
          undefined
        }
        initialProjectId={assignmentPrefill.projectId}
        initialOperatorId={assignmentPrefill.operatorId}
        lockEquipment={Boolean(assignment)}
        lockOperator={Boolean(assignment)}
        initialProjectWarning={assignmentProjectError}
      />}

    </div>
  );
}
